package com.example.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;


public class MainActivity extends AppCompatActivity {


    private EditText RemainingGas;
    private EditText PriceOfGasoline;
    private Button CalculatePriceButton;
    private TextView Result;
    private EditText GasTankCapacity;

    private RadioGroup radioGroupMeasurementOption;
    private RadioButton GallonsOpt;
    private RadioButton LitersOpt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RemainingGas = (EditText) findViewById(R.id.amountOfRemainingGas);
        PriceOfGasoline = (EditText) findViewById(R.id.PriceOfGas);
        CalculatePriceButton = (Button) findViewById((R.id.CalculateButton));
        Result = (TextView) findViewById(R.id.ResultOfGasPriceTextView);
        GasTankCapacity = (EditText) findViewById(R.id.editTextGasTankCapacity);

        radioGroupMeasurementOption = (RadioGroup) findViewById(R.id.radioGroupMeasurementOption);
        GallonsOpt = (RadioButton) findViewById(R.id.radioButtonGallon);
        LitersOpt = (RadioButton) findViewById(R.id.radioButtonLiters);

        CalculatePriceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            //When the calculate button is pressed
            public void onClick(View view) {

                // Round the price of the gas needed to 3 decimal spaces
                BigDecimal bd = new BigDecimal((checkboxGallonsOrLiters())).setScale(3, RoundingMode.HALF_UP);
                double testing = bd.doubleValue();

                Result.setText("Price: "+ testing);

            }

            // Check the checkboxes to make sure only one is selected, easter egg if both
            public double checkboxGallonsOrLiters() {

                double Price = 0.0;
                int percentageOfGas = 0;
                double PriceOfGas = 0.0;
                double GasTankCap = 0.0;
                String checkPriceOfGas = " ";
                String checkPercentageOfGas = " ";
                String checkGasTankCapacity = " ";

                checkPriceOfGas = PriceOfGasoline.getText().toString();
                checkPercentageOfGas = RemainingGas.getText().toString();
                checkGasTankCapacity =  GasTankCapacity.getText().toString();

                // If both are selected
                if ((checkPercentageOfGas.isEmpty() || checkPriceOfGas.isEmpty() || checkGasTankCapacity.isEmpty()))
                {
                    return Price = 0.0;
                }

                if(radioGroupMeasurementOption.getCheckedRadioButtonId() == -1)
                {
                    return Price = 0.0;
                }

                // Get the values for the gas tank capacity, percentage filled and price of gas
                percentageOfGas = Integer.parseInt(RemainingGas.getText().toString());
                PriceOfGas = Double.parseDouble(PriceOfGasoline.getText().toString());
                GasTankCap = Double.parseDouble(GasTankCapacity.getText().toString());

                double TankGas = 100 - percentageOfGas;
                TankGas = TankGas / 100;
                double neededGas = GasTankCap * TankGas;

                // If gallon was selected
                if (GallonsOpt.isChecked()) {

                    Price = PriceOfGas * neededGas;

                }

                // If liter was selected
                if (LitersOpt.isChecked()){

                    //Convert the liters to gallons
                    neededGas = neededGas * 3.785;
                    Price = PriceOfGas * neededGas;

                }

                return Price ;
            }
        });
    }
}